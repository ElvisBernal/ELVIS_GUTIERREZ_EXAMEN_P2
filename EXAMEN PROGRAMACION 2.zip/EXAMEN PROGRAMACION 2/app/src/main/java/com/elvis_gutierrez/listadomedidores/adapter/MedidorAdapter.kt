package com.elvis_gutierrez.listadomedidores.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.elvis_gutierrez.listadomedidores.R
import com.elvis_gutierrez.listadomedidores.model.Medidor

class MedidorAdapter(
    private var lista: List<Medidor>
) : RecyclerView.Adapter<MedidorAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val imgTipo: ImageView = view.findViewById(R.id.imgTipo)
        val tipo: TextView = view.findViewById(R.id.txtTipo)
        val valor: TextView = view.findViewById(R.id.txtValor)
        val fecha: TextView = view.findViewById(R.id.txtFecha)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_medidor, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val item = lista[position]

        holder.tipo.text = item.tipo
        holder.valor.text = "Valor: ${item.valor}"
        holder.fecha.text = item.fecha

        // 🔥 IMAGEN SEGÚN TIPO
        val imagen = when (item.tipo) {
            "Agua" -> R.drawable.ic_agua
            "Luz" -> R.drawable.ic_luz
            "Gas" -> R.drawable.ic_gas
            else -> R.drawable.ic_agua
        }

        holder.imgTipo.setImageResource(imagen)
    }

    override fun getItemCount(): Int = lista.size

    fun actualizarLista(nuevaLista: List<Medidor>) {
        lista = nuevaLista
        notifyDataSetChanged()
    }
}