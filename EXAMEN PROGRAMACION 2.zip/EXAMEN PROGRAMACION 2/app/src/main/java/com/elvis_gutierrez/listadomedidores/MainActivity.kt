package com.elvis_gutierrez.listadomedidores

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.elvis_gutierrez.listadomedidores.adapter.MedidorAdapter
import com.elvis_gutierrez.listadomedidores.data.AppDatabase
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: MedidorAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnAgregar = findViewById<Button>(R.id.btnAgregar)
        val recycler = findViewById<RecyclerView>(R.id.recyclerView)

        val db = AppDatabase.getDatabase(this)

        adapter = MedidorAdapter(mutableListOf())

        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        btnAgregar.setOnClickListener {
            startActivity(Intent(this, FormMedidorActivity::class.java))
        }

        cargarDatos(db)
    }

    override fun onResume() {
        super.onResume()
        cargarDatos(AppDatabase.getDatabase(this))
    }

    private fun cargarDatos(db: AppDatabase) {
        lifecycleScope.launch {
            val lista = db.medidorDao().obtenerTodos()
            adapter.actualizarLista(lista)
        }
    }
}