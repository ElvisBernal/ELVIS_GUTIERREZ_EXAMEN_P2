package com.elvis_gutierrez.listadomedidores.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.elvis_gutierrez.listadomedidores.data.AppDatabase
import com.elvis_gutierrez.listadomedidores.model.Medidor
import kotlinx.coroutines.launch

class MedidorViewModel(application: Application)
    : AndroidViewModel(application) {

    private val dao = AppDatabase
        .getDatabase(application)
        .medidorDao()

    val listaMediciones = MutableLiveData<List<Medidor>>()

    fun cargarMediciones() {
        viewModelScope.launch {
            listaMediciones.value = dao.obtenerTodos()
        }
    }

    fun guardarMedicion(medidor: Medidor) {
        viewModelScope.launch {
            dao.insertar(medidor)
            cargarMediciones()
        }
    }
}