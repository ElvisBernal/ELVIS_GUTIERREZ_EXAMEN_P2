package com.elvis_gutierrez.listadomedidores.data

import androidx.room.*
import com.elvis_gutierrez.listadomedidores.model.Medidor

@Dao
interface MedidorDao {

    @Insert
    suspend fun insertar(medidor: Medidor)

    @Query("SELECT * FROM mediciones")
    suspend fun obtenerTodos(): List<Medidor>

    @Delete
    suspend fun eliminar(medidor: Medidor)

    @Update
    suspend fun actualizar(medidor: Medidor)
}