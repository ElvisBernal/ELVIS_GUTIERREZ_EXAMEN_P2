package com.elvis_gutierrez.listadomedidores.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "mediciones")
data class Medidor(

    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val tipo: String,
    val valor: Int,
    val fecha: String
)