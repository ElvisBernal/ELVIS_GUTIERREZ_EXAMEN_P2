package com.elvis_gutierrez.listadomedidores

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.elvis_gutierrez.listadomedidores.data.AppDatabase
import com.elvis_gutierrez.listadomedidores.model.Medidor
import kotlinx.coroutines.launch

class FormMedidorActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form_medidor)


        val edtValor = findViewById<EditText>(R.id.edtValorMedidor)
        val edtFecha = findViewById<EditText>(R.id.edtFecha)
        val radioTipo = findViewById<RadioGroup>(R.id.radioTipoMedidor)
        val btnRegistrar = findViewById<Button>(R.id.btnRegistrarMedicion)

        val db = AppDatabase.getDatabase(this)

        btnRegistrar.setOnClickListener {

            //  Obtener tipo desde RadioButton
            val tipo = when (radioTipo.checkedRadioButtonId) {
                R.id.rbAgua -> "Agua"
                R.id.rbLuz -> "Luz"
                R.id.rbGas -> "Gas"
                else -> "Agua"
            }

            //  Validacion segura del valor
            val valor = edtValor.text.toString().toIntOrNull() ?: 0
            val fecha = edtFecha.text.toString()

            val medidor = Medidor(
                tipo = tipo,
                valor = valor,
                fecha = fecha
            )

            lifecycleScope.launch {
                db.medidorDao().insertar(medidor)
                finish() //Vuelve a pagina principal
            }
        }
    }
}